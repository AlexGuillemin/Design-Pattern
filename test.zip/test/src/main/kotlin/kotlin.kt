import org.apache.commons.csv.CSVFormat
import org.apache.commons.csv.CSVParser
import java.nio.file.Paths
import java.nio.file.Files


fun main() {
    val CSV_File_Path = "C://Users/am-gu/Desktop/data_csv.csv"

    val reader = Files.newBufferedReader(Paths.get(CSV_File_Path))
    val csvParser = CSVParser(reader, CSVFormat.DEFAULT
        .withFirstRecordAsHeader()
        .withDelimiter(';')
        .withIgnoreHeaderCase()
        .withTrim())
    for (csvRecord in csvParser) {
        // Accessing values by the names assigned to each column
        val annee = csvRecord.get("Annee")
        val appareil = csvRecord.get("Appareil")
        val commandes = csvRecord.get("Commandes")
        val impressions = csvRecord.get("Impressions")
        val clics = csvRecord.get("Clics")
        val cout = csvRecord.get("Cout")
        val pm = csvRecord.get("PM")
        val ca = csvRecord.get("CA")
        val reseaurechercher = csvRecord.get("Reseaurechercher")
        val mois = csvRecord.get("Mois")



        println("Record No - " + csvRecord.recordNumber)
        println("---------------")
        println("Annee : $annee")
        println("Appareil : $appareil")
        println("Commandes : $commandes")
        println("Impressions : $impressions")
        println("Clics : $clics")
        println("Cout : $cout")
        println("PM : $pm")
        println("CA : $ca")
        println("Reseaurechercher : $reseaurechercher")
        println("Mois : $mois")


        println("---------------\n\n")
    }
}